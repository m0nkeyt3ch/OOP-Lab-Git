package jProfiler;

public class ExcDemoCompare {
	public static void main( String[] args ) {
	int a=0;
	try{
		for (int i=0; i<1000000;i++){
		a++;
		}
	}
	catch(Exception e){
	}

   }
}