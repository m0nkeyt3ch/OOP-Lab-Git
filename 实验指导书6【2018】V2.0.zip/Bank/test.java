﻿package Bank;

import java.util.ArrayList;



public class test {

	/**
	 * @param args
	 */
	public static AccountSet accountset = new AccountSet();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account a1=new Account("01","jane","123");
		accountset.insert(a1);
		Account a2=new Account("02","greece","123");
		accountset.insert(a2);
		/*
		code continue
		*/
		
	}

}
